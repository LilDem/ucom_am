package am.qa.itu.ucom.lang;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

public class UcomTest extends SovatsBaseTest{
	
@Test
public void checkUcomSupport() {
	driver.get("https://ucom.am");
	driver.findElement(By.xpath("//a[contains(@class, 'txt-menu')]")).click();
	Assert.assertTrue(driver.findElement(By.xpath("//img[@src='/file_manager/Icons/Contact us/file_manager_temp/Ucom_icon_tel.png']")).isDisplayed());
	driver.findElement(By.xpath("//a[@class= 'fs16 fedra-medium' and contains(@href, 'necessary-documents')]")).click();
	Assert.assertTrue(driver.findElement(By.xpath("//a[@href='/file_manager/poa/hy.pdf']")).isDisplayed());
	driver.findElement(By.xpath("//a[@class='db sprite']")).click();
	driver.findElement(By.xpath("//a[@href='https://www.ucom.am/hy/business/']")).click();
	driver.findElement(By.xpath("//a[@class='db pr' and @href ='https://www.ucom.am/hy/business/business-solutions/']")).click();
	Assert.assertTrue(driver.findElement(By.xpath("//img[@src='/file_manager/uFleet_banner.png']")).isDisplayed());
	
	}
	
	
	

}
